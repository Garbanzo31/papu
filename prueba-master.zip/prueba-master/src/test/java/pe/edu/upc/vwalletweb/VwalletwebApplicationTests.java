package pe.edu.upc.vwalletweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VwalletwebApplicationTests {

    @Test
    void contextLoads() {
    }

}
