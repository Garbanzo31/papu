package pe.edu.upc.vwalletweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VwalletwebApplication {

    public static void main(String[] args) {
        SpringApplication.run(VwalletwebApplication.class, args);
    }

}
